# Unidad 4 POO Eventos
Programación Orientada a Eventos - Python Tkinter
En este repositorio se encontrarán las clases ejemplo, desarroladas en la Unidad 4 de la asignatura Programación Orientada a Objetos, carreras Licenciatura en Sistemas de Información, Licenciatura en Ciencias de la Computación y Tecnicatura en Programación WEB, Departamento de Informática, Facultad de Ciencias Exactas, Físicas y Naturales de la UNSJ.
